// database/db.js
// Opens (or creates) netpulse.db, defines the schema, and seeds it with
// starter devices the first time the app runs.

const path = require('path');
const Database = require('better-sqlite3');

const DB_PATH = path.join(__dirname, 'netpulse.db');
const db = new Database(DB_PATH);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

function init() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS devices (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      hostname    TEXT NOT NULL,
      ip          TEXT NOT NULL,
      type        TEXT NOT NULL DEFAULT 'Device',
      location    TEXT DEFAULT '',
      status      TEXT NOT NULL DEFAULT 'online',   -- online | offline | warning
      latency_ms  INTEGER DEFAULT 0,
      last_seen   TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS incidents (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      device_id    INTEGER NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
      detected_at  TEXT NOT NULL DEFAULT (datetime('now')),
      resolved_at  TEXT,
      status       TEXT NOT NULL DEFAULT 'open'      -- open | investigating | resolved | ignored
    );

    CREATE TABLE IF NOT EXISTS events (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp  TEXT NOT NULL DEFAULT (datetime('now')),
      device_id  INTEGER REFERENCES devices(id) ON DELETE SET NULL,
      severity   TEXT NOT NULL DEFAULT 'info',        -- info | warning | critical
      message    TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS latency_history (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      timestamp    TEXT NOT NULL DEFAULT (datetime('now')),
      avg_latency  REAL NOT NULL
    );
  `);

  const count = db.prepare('SELECT COUNT(*) AS n FROM devices').get().n;
  if (count === 0) seed();
}

function seed() {
  const insert = db.prepare(`
    INSERT INTO devices (hostname, ip, type, location, status, latency_ms)
    VALUES (@hostname, @ip, @type, @location, @status, @latency_ms)
  `);

  const starterDevices = [
    { hostname: 'Router-GW',     ip: '192.168.1.1',  type: 'Router',       location: 'Server Room', status: 'online', latency_ms: 12 },
    { hostname: 'Core-Switch',   ip: '192.168.1.2',  type: 'Switch',       location: 'Server Room', status: 'online', latency_ms: 3  },
    { hostname: 'WiFi-AP-01',    ip: '192.168.1.3',  type: 'Access Point', location: 'Floor 2',      status: 'online', latency_ms: 8  },
    { hostname: 'Web-Server',    ip: '192.168.1.10', type: 'Server',       location: 'Server Room', status: 'online', latency_ms: 28 },
    { hostname: 'DNS-Server',    ip: '192.168.1.11', type: 'Server',       location: 'Server Room', status: 'online', latency_ms: 18 },
    { hostname: 'DB-Server',     ip: '192.168.1.12', type: 'Server',       location: 'Server Room', status: 'online', latency_ms: 22 },
    { hostname: 'Office-PC-07',  ip: '192.168.1.27', type: 'Workstation',  location: 'Floor 1',      status: 'online', latency_ms: 14 },
    { hostname: 'Office-PC-12',  ip: '192.168.1.32', type: 'Workstation',  location: 'Floor 1',      status: 'online', latency_ms: 16 },
    { hostname: 'Laptop-Dana',   ip: '192.168.1.55', type: 'Laptop',       location: 'Floor 2',      status: 'online', latency_ms: 31 },
    { hostname: 'Phone-Josh',    ip: '192.168.1.61', type: 'Mobile',       location: 'Floor 2',      status: 'online', latency_ms: 44 },
  ];

  const insertMany = db.transaction((rows) => rows.forEach((r) => insert.run(r)));
  insertMany(starterDevices);

  db.prepare(`INSERT INTO events (severity, message) VALUES (?, ?)`)
    .run('info', 'NetPulse initialized — 10 devices seeded');
}

module.exports = { db, init };
