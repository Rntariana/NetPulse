// frontend/js/common.js
// Loaded on every page before the page-specific script.

const API_BASE = '/api';

async function apiGet(path) {
  const res = await fetch(`${API_BASE}${path}`);
  if (!res.ok) throw new Error(`GET ${path} failed: ${res.status}`);
  return res.json();
}

async function apiSend(method, path, body) {
  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) throw new Error(`${method} ${path} failed: ${res.status}`);
  return res.status === 204 ? null : res.json();
}

function formatTime(isoOrSqliteString) {
  if (!isoOrSqliteString) return '';
  const d = new Date(isoOrSqliteString.replace(' ', 'T') + 'Z');
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function statusChipHtml(status) {
  const map = {
    online: ['ONLINE', 'status-online'],
    offline: ['OFFLINE', 'status-offline'],
    warning: ['WARNING', 'status-warning'],
  };
  const [label, cls] = map[status] || map.online;
  return `<span class="status-chip ${cls}"><span class="dot"></span>${label}</span>`;
}

// Called once per page once the socket is created, to wire the sidebar
// connection indicator that every page shares.
function bindConnectionIndicator(socket) {
  const el = document.getElementById('conn-status');
  if (!el) return;
  socket.on('connect', () => {
    el.classList.add('connected');
    el.querySelector('.label').textContent = 'Live · connected';
  });
  socket.on('disconnect', () => {
    el.classList.remove('connected');
    el.querySelector('.label').textContent = 'Disconnected';
  });
}
