// frontend/js/topology.js

const socket = io();
bindConnectionIndicator(socket);

let devices = [];

// Wired device types hang off the switch; wireless types hang off the AP.
const WIRELESS_TYPES = new Set(['Laptop', 'Mobile']);

function node(d, big) {
  return `
    <div class="topo-node ${d.status}" style="${big ? 'min-width:130px;' : ''}">
      <div class="n-label">${d.hostname}</div>
      <div class="n-ip">${d.ip}</div>
    </div>`;
}

function branch(list) {
  if (!list.length) return '';
  return `<div style="display:flex;gap:14px;flex-wrap:wrap;justify-content:center;margin-top:10px;">
    ${list.map((d) => node(d, false)).join('')}
  </div>`;
}

function render() {
  const router = devices.find((d) => d.type === 'Router');
  const switchNode = devices.find((d) => d.type === 'Switch');
  const apNode = devices.find((d) => d.type === 'Access Point');
  const rest = devices.filter((d) => !['Router', 'Switch', 'Access Point'].includes(d.type));
  const wired = rest.filter((d) => !WIRELESS_TYPES.has(d.type));
  const wireless = rest.filter((d) => WIRELESS_TYPES.has(d.type));

  const wrap = document.getElementById('topology-wrap');

  if (!router) {
    wrap.innerHTML = `<div style="padding:20px;color:var(--muted);">No router registered yet — add one on the Devices page.</div>`;
    return;
  }

  wrap.innerHTML = `
    <div style="display:flex;flex-direction:column;align-items:center;gap:6px;">
      <div style="font-size:11px;color:var(--muted-2);letter-spacing:.08em;">INTERNET</div>
      <div style="width:1px;height:18px;background:var(--border);"></div>
      ${node(router, true)}
      <div style="width:1px;height:18px;background:var(--border);"></div>
      <div style="display:flex;gap:60px;flex-wrap:wrap;justify-content:center;">
        <div style="display:flex;flex-direction:column;align-items:center;">
          ${switchNode ? node(switchNode, false) : '<div style="color:var(--muted-2);font-size:11px;">No switch</div>'}
          ${branch(wired)}
        </div>
        <div style="display:flex;flex-direction:column;align-items:center;">
          ${apNode ? node(apNode, false) : '<div style="color:var(--muted-2);font-size:11px;">No access point</div>'}
          ${branch(wireless)}
        </div>
      </div>
    </div>`;
}

async function boot() {
  devices = await apiGet('/devices');
  render();
}

socket.on('device:new', (device) => { devices.push(device); render(); });
socket.on('device:update', (device) => {
  const idx = devices.findIndex((d) => d.id === device.id);
  if (idx >= 0) devices[idx] = device;
  render();
});
socket.on('device:removed', ({ id }) => {
  devices = devices.filter((d) => d.id !== id);
  render();
});

boot();
