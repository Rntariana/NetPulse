// frontend/js/charts.js
// Thin wrapper around Chart.js so dashboard.js doesn't repeat config.

function createLatencyChart(canvasId, initialPoints = []) {
  const ctx = document.getElementById(canvasId).getContext('2d');

  const gradient = ctx.createLinearGradient(0, 0, 0, 160);
  gradient.addColorStop(0, 'rgba(94,169,255,0.35)');
  gradient.addColorStop(1, 'rgba(94,169,255,0)');

  const chart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: initialPoints.map((p) => p.label),
      datasets: [
        {
          label: 'Avg response time (ms)',
          data: initialPoints.map((p) => p.value),
          borderColor: '#5ea9ff',
          backgroundColor: gradient,
          borderWidth: 2,
          pointRadius: 0,
          pointHoverRadius: 4,
          tension: 0.35,
          fill: true,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 300 },
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: '#141922',
          borderColor: '#20262f',
          borderWidth: 1,
          titleColor: '#e6e9ef',
          bodyColor: '#7c8798',
          padding: 8,
          callbacks: { label: (item) => `${item.parsed.y} ms` },
        },
      },
      scales: {
        x: { display: false },
        y: {
          grid: { color: '#20262f' },
          ticks: { color: '#4d5666', font: { size: 10 }, maxTicksLimit: 4 },
          beginAtZero: true,
        },
      },
    },
  });

  return {
    chart,
    pushPoint(label, value) {
      chart.data.labels.push(label);
      chart.data.datasets[0].data.push(value);
      if (chart.data.labels.length > 30) {
        chart.data.labels.shift();
        chart.data.datasets[0].data.shift();
      }
      chart.update('none');
    },
    setPoints(points) {
      chart.data.labels = points.map((p) => p.label);
      chart.data.datasets[0].data = points.map((p) => p.value);
      chart.update();
    },
  };
}
