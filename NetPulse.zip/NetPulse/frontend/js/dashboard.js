// frontend/js/dashboard.js

const socket = io();
bindConnectionIndicator(socket);

let devices = [];
let activeIncident = null; // the incident currently shown in the banner

/* ---------------- Rendering ---------------- */

function renderDevices() {
  const rows = devices
    .slice()
    .sort((a, b) => a.hostname.localeCompare(b.hostname))
    .map((d) => `
      <tr>
        <td><div class="dev-name">${d.hostname}</div><div class="dev-ip">${d.ip}</div></td>
        <td>${statusChipHtml(d.status)}</td>
        <td class="latency ${d.status !== 'offline' && d.latency_ms > 35 ? 'warn' : ''}">
          ${d.status === 'offline' ? '—' : d.latency_ms + 'ms'}
        </td>
        <td style="color:var(--muted)">${d.type}</td>
      </tr>`)
    .join('');
  document.getElementById('device-rows').innerHTML = rows;
  document.getElementById('device-count').textContent = `${devices.length} total`;
}

function renderStats(stats) {
  document.getElementById('stat-total').textContent = stats.total;
  document.getElementById('stat-online').textContent = stats.online;
  document.getElementById('stat-offline').textContent = stats.offline;
  document.getElementById('stat-latency').textContent = `${stats.avgLatency}ms`;
}

function renderEvent(e) {
  const colorMap = { info: 'var(--green)', warning: 'var(--amber)', critical: 'var(--red)' };
  const list = document.getElementById('log-list');
  const item = document.createElement('div');
  item.className = 'log-item';
  item.innerHTML = `
    <div class="log-time">${formatTime(e.timestamp)}</div>
    <div class="log-dot" style="background:${colorMap[e.severity] || colorMap.info}"></div>
    <div class="log-text">${e.message}</div>`;
  list.prepend(item);
  while (list.children.length > 40) list.removeChild(list.lastChild);
  document.getElementById('log-count').textContent = `${list.children.length} entries`;
}

function renderEventList(events) {
  document.getElementById('log-list').innerHTML = '';
  events.forEach(renderEvent);
}

function renderIncidentRows(incidents) {
  const openOrRecent = incidents.slice(0, 8);
  document.getElementById('incident-rows').innerHTML = openOrRecent.length
    ? openOrRecent.map((i) => `
        <div class="incident-row">
          <div class="info">
            <b>${i.hostname}</b>
            <span>${i.ip} · detected ${formatTime(i.detected_at)}</span>
          </div>
          ${statusChipHtml(i.status === 'resolved' || i.status === 'ignored' ? 'online' : 'offline')}
        </div>`).join('')
    : `<div style="padding:20px 16px;color:var(--muted);font-size:12.5px;">No incidents yet — all devices healthy.</div>`;
  document.getElementById('incident-count').textContent = `${incidents.length} total`;

  const openCount = incidents.filter((i) => i.status === 'open' || i.status === 'investigating').length;
  document.getElementById('incident-nav-count').textContent = openCount > 0 ? openCount : '';
}

function showIncidentBanner(incident) {
  activeIncident = incident;
  document.getElementById('inc-title').textContent = `INCIDENT DETECTED — ${incident.hostname}`;
  document.getElementById('inc-meta').textContent =
    `${incident.ip} · Status: OFFLINE · Detected ${formatTime(incident.detected_at)}`;
  document.getElementById('incident-banner').classList.add('show');
}

async function setIncidentState(status) {
  if (!activeIncident) return;
  await apiSend('PATCH', `/incidents/${activeIncident.id}`, { status });
  document.getElementById('incident-banner').classList.remove('show');
  activeIncident = null;
}

/* ---------------- Chart ---------------- */

let latencyChart;

/* ---------------- Boot ---------------- */

async function boot() {
  const [deviceList, stats, events, incidents, history] = await Promise.all([
    apiGet('/devices'),
    apiGet('/devices/stats'),
    apiGet('/events'),
    apiGet('/incidents'),
    apiGet('/events/latency-history'),
  ]);

  devices = deviceList;
  renderDevices();
  renderStats(stats);
  renderEventList(events);
  renderIncidentRows(incidents);

  const points = history.length
    ? history.map((h) => ({ label: formatTime(h.timestamp), value: Math.round(h.avg_latency) }))
    : [{ label: formatTime(new Date().toISOString()), value: stats.avgLatency }];
  latencyChart = createLatencyChart('latency-chart', points);

  const openIncident = incidents.find((i) => i.status === 'open' || i.status === 'investigating');
  if (openIncident) showIncidentBanner(openIncident);
}

/* ---------------- Live socket events ---------------- */

socket.on('device:update', (device) => {
  const idx = devices.findIndex((d) => d.id === device.id);
  if (idx >= 0) devices[idx] = device; else devices.push(device);
  renderDevices();
});

socket.on('device:new', (device) => {
  devices.push(device);
  renderDevices();
});

socket.on('device:removed', ({ id }) => {
  devices = devices.filter((d) => d.id !== id);
  renderDevices();
});

socket.on('stats:update', renderStats);

socket.on('event:new', renderEvent);

socket.on('latency:point', (point) => {
  if (latencyChart) latencyChart.pushPoint(formatTime(point.timestamp), Math.round(point.avgLatency));
});

socket.on('incident:new', (incident) => {
  showIncidentBanner(incident);
  apiGet('/incidents').then(renderIncidentRows);
});

socket.on('incident:update', () => {
  apiGet('/incidents').then(renderIncidentRows);
});

boot();
