// frontend/js/devices.js

const socket = io();
bindConnectionIndicator(socket);

let devices = [];

function render() {
  document.getElementById('device-rows').innerHTML = devices
    .slice()
    .sort((a, b) => a.hostname.localeCompare(b.hostname))
    .map((d) => `
      <tr>
        <td><div class="dev-name">${d.hostname}</div><div class="dev-ip">${d.ip}</div></td>
        <td>${statusChipHtml(d.status)}</td>
        <td class="latency">${d.status === 'offline' ? '—' : d.latency_ms + 'ms'}</td>
        <td style="color:var(--muted)">${d.type}</td>
        <td style="color:var(--muted)">${d.location || '—'}</td>
        <td>
          <div class="row-actions">
            <button onclick="openModal(${d.id})">Edit</button>
            <button class="danger" onclick="deleteDevice(${d.id})">Delete</button>
          </div>
        </td>
      </tr>`)
    .join('');
}

async function boot() {
  devices = await apiGet('/devices');
  render();
}

/* ---------------- Modal / form ---------------- */

function openModal(id) {
  const backdrop = document.getElementById('modal-backdrop');
  const device = id ? devices.find((d) => d.id === id) : null;

  document.getElementById('modal-title').textContent = device ? 'Edit device' : 'Add device';
  document.getElementById('device-id').value = device ? device.id : '';
  document.getElementById('f-hostname').value = device ? device.hostname : '';
  document.getElementById('f-ip').value = device ? device.ip : '';
  document.getElementById('f-type').value = device ? device.type : 'Server';
  document.getElementById('f-location').value = device ? device.location : '';

  backdrop.classList.add('show');
}

function closeModal() {
  document.getElementById('modal-backdrop').classList.remove('show');
}

async function submitDevice() {
  const id = document.getElementById('device-id').value;
  const payload = {
    hostname: document.getElementById('f-hostname').value.trim(),
    ip: document.getElementById('f-ip').value.trim(),
    type: document.getElementById('f-type').value,
    location: document.getElementById('f-location').value.trim(),
  };
  if (!payload.hostname || !payload.ip) {
    alert('Hostname and IP are required.');
    return;
  }

  if (id) {
    await apiSend('PATCH', `/devices/${id}`, payload);
  } else {
    await apiSend('POST', '/devices', payload);
  }
  closeModal();
}

async function deleteDevice(id) {
  if (!confirm('Remove this device from monitoring?')) return;
  await apiSend('DELETE', `/devices/${id}`);
}

/* ---------------- Live updates ---------------- */

socket.on('device:new', (device) => { devices.push(device); render(); });
socket.on('device:update', (device) => {
  const idx = devices.findIndex((d) => d.id === device.id);
  if (idx >= 0) devices[idx] = device;
  render();
});
socket.on('device:removed', ({ id }) => {
  devices = devices.filter((d) => d.id !== id);
  render();
});

boot();
