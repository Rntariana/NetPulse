# NetPulse

A real-time network monitoring and infrastructure dashboard. NetPulse tracks devices, latency, uptime, and incidents across a network, and pushes live updates to every connected browser over WebSockets.

## Features

- 📡 **Device monitoring** — hostname, IP, type, location, status, latency
- 📊 **Live charts** — real-time latency history rendered with Chart.js
- 🚨 **Incident detection** — auto-opens an incident when a device drops, with Investigating / Resolved / Ignored states
- 🗺️ **Network topology** — visual tree of router → switch/AP → devices, live-updated
- 📜 **Event log** — timestamped history of every status change
- 🔄 **Real-time updates** — Socket.IO pushes changes instantly, no polling
- 🗄️ **Persistent storage** — SQLite via better-sqlite3, survives restarts

## Tech stack

| Layer | Technology |
|---|---|
| Frontend | HTML5, CSS3, vanilla JavaScript, Chart.js |
| Backend | Node.js, Express.js |
| Real-time | Socket.IO |
| Database | SQLite (better-sqlite3) |

## Project structure

```
NetPulse/
├── frontend/
│   ├── index.html          # redirects to dashboard.html
│   ├── dashboard.html
│   ├── devices.html
│   ├── topology.html
│   ├── css/style.css
│   └── js/
│       ├── common.js       # shared fetch helpers, formatting
│       ├── charts.js       # Chart.js wrapper
│       ├── dashboard.js
│       ├── devices.js
│       └── topology.js
├── backend/
│   ├── server.js           # Express + Socket.IO entry point
│   ├── routes/              # devices.js, incidents.js, events.js
│   ├── controllers/         # request handlers
│   └── services/
│       ├── deviceService.js    # SQL access layer
│       └── monitorService.js   # the live-check engine
├── database/
│   └── db.js                # schema + seed data (netpulse.db is created here at runtime)
├── package.json
└── .gitignore
```

## Getting started

```bash
git clone <your-repo-url>
cd NetPulse
npm install
npm start
```

Then open **http://localhost:3000**.

`npm run dev` runs the server with `nodemon` for auto-restart while developing.

The SQLite database (`database/netpulse.db`) is created automatically on first run and seeded with 10 sample devices — no manual setup required.

## How the live monitoring works

`backend/services/monitorService.js` runs a check cycle every 3.5 seconds. Right now it **simulates** checks (drifts latency, occasionally drops a device) so the dashboard is fully demonstrable without a real network to point it at. Every change is written to SQLite and broadcast over Socket.IO, which is what makes the dashboard, devices, and topology pages all update instantly and stay in sync with each other.

### Swapping in real checks

To monitor an actual network, replace the random logic inside `runCheckCycle()` with real probes, for example:

```js
const ping = require('ping'); // npm install ping
const res = await ping.promise.probe(device.ip, { timeout: 2 });
const status = res.alive ? 'online' : 'offline';
const latency = res.alive ? Math.round(res.time) : null;
```

Everything downstream — the database writes, incident creation, Socket.IO broadcasts, and every chart and table on the frontend — needs no changes, since it all just reacts to `deviceService.update()` calls.

## REST API

| Method | Route | Description |
|---|---|---|
| GET | `/api/devices` | List all devices |
| GET | `/api/devices/stats` | Summary counts + avg latency |
| GET | `/api/devices/:id` | Get one device |
| POST | `/api/devices` | Add a device |
| PATCH | `/api/devices/:id` | Update a device |
| DELETE | `/api/devices/:id` | Remove a device |
| GET | `/api/incidents` | List recent incidents |
| PATCH | `/api/incidents/:id` | Update incident status |
| GET | `/api/events` | Recent event log |
| GET | `/api/events/latency-history` | Latency history points for the chart |

## Socket.IO events

| Event | Payload | Fired when |
|---|---|---|
| `device:update` | device | status or latency changes |
| `device:new` | device | a device is added |
| `device:removed` | `{ id }` | a device is deleted |
| `stats:update` | stats summary | after any device change |
| `event:new` | event | any loggable event occurs |
| `incident:new` | incident | a device goes offline |
| `incident:update` | incident | an incident's status changes |
| `latency:point` | `{ timestamp, avgLatency }` | each check cycle, for the chart |

## Future improvements

- SNMP monitoring for switches/routers
- MikroTik API integration
- Email / Telegram alerting on incidents
- Docker deployment
- Role-based access control
- Mobile-responsive dashboard view

## License

MIT
