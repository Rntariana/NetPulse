const express = require('express');
const router = express.Router();
const devicesController = require('../controllers/devicesController');

router.get('/', devicesController.list);
router.get('/stats', devicesController.stats);
router.get('/:id', devicesController.get);
router.post('/', devicesController.create);
router.patch('/:id', devicesController.update);
router.delete('/:id', devicesController.remove);

module.exports = router;
