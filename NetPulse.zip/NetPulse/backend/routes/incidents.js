const express = require('express');
const router = express.Router();
const incidentsController = require('../controllers/incidentsController');

router.get('/', incidentsController.list);
router.patch('/:id', incidentsController.updateStatus);

module.exports = router;
