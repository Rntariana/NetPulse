const express = require('express');
const router = express.Router();
const eventsController = require('../controllers/eventsController');

router.get('/', eventsController.list);
router.get('/latency-history', eventsController.latencyHistory);

module.exports = router;
