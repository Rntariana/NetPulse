// backend/server.js
const path = require('path');
const express = require('express');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');

const { init } = require('../database/db');
const { startMonitor } = require('./services/monitorService');

const devicesRouter = require('./routes/devices');
const incidentsRouter = require('./routes/incidents');
const eventsRouter = require('./routes/events');

const PORT = process.env.PORT || 3000;

// 1. Make sure the DB and tables exist before anything else touches them
init();

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(cors());
app.use(express.json());
app.set('io', io); // controllers reach the socket instance via req.app.get('io')

// 2. REST API
app.use('/api/devices', devicesRouter);
app.use('/api/incidents', incidentsRouter);
app.use('/api/events', eventsRouter);

// 3. Serve the frontend
app.use(express.static(path.join(__dirname, '..', 'frontend')));
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'frontend', 'dashboard.html'));
});

// 4. Socket.IO — just logs connections; all real events are emitted
//    from the controllers and the monitor service.
io.on('connection', (socket) => {
  console.log(`[socket] client connected: ${socket.id}`);
  socket.on('disconnect', () => console.log(`[socket] client disconnected: ${socket.id}`));
});

// 5. Kick off the live-monitoring loop
startMonitor(io);

server.listen(PORT, () => {
  console.log(`\n  NetPulse running → http://localhost:${PORT}\n`);
});
