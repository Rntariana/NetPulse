const { eventService, latencyService } = require('../services/deviceService');

exports.list = (req, res) => {
  const limit = Number(req.query.limit) || 40;
  res.json(eventService.getRecent(limit));
};

exports.latencyHistory = (req, res) => {
  const limit = Number(req.query.limit) || 30;
  res.json(latencyService.recent(limit));
};
