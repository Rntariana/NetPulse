const { incidentService, eventService } = require('../services/deviceService');

const VALID_STATUSES = ['open', 'investigating', 'resolved', 'ignored'];

exports.list = (req, res) => {
  res.json(incidentService.getAll());
};

exports.updateStatus = (req, res) => {
  const { status } = req.body;
  if (!VALID_STATUSES.includes(status)) {
    return res.status(400).json({ error: `status must be one of ${VALID_STATUSES.join(', ')}` });
  }
  const incident = incidentService.updateStatus(req.params.id, status);
  if (!incident) return res.status(404).json({ error: 'Incident not found' });

  const event = eventService.log({
    deviceId: incident.device_id,
    severity: status === 'resolved' ? 'info' : 'warning',
    message: `Incident on ${incident.hostname} marked ${status}`,
  });

  req.app.get('io').emit('incident:update', incident);
  req.app.get('io').emit('event:new', event);
  res.json(incident);
};
