const { deviceService, eventService } = require('../services/deviceService');

exports.list = (req, res) => {
  res.json(deviceService.getAll());
};

exports.get = (req, res) => {
  const device = deviceService.getById(req.params.id);
  if (!device) return res.status(404).json({ error: 'Device not found' });
  res.json(device);
};

exports.create = (req, res) => {
  const { hostname, ip, type, location } = req.body;
  if (!hostname || !ip) {
    return res.status(400).json({ error: 'hostname and ip are required' });
  }
  const device = deviceService.create({ hostname, ip, type, location });
  const event = eventService.log({ deviceId: device.id, severity: 'info', message: `${device.hostname} added to monitoring` });
  req.app.get('io').emit('device:new', device);
  req.app.get('io').emit('event:new', event);
  res.status(201).json(device);
};

exports.update = (req, res) => {
  const updated = deviceService.update(req.params.id, req.body);
  if (!updated) return res.status(404).json({ error: 'Device not found' });
  req.app.get('io').emit('device:update', updated);
  res.json(updated);
};

exports.remove = (req, res) => {
  const device = deviceService.getById(req.params.id);
  const ok = deviceService.remove(req.params.id);
  if (!ok) return res.status(404).json({ error: 'Device not found' });
  req.app.get('io').emit('device:removed', { id: Number(req.params.id) });
  if (device) {
    const event = eventService.log({ severity: 'info', message: `${device.hostname} removed from monitoring` });
    req.app.get('io').emit('event:new', event);
  }
  res.status(204).end();
};

exports.stats = (req, res) => {
  res.json(deviceService.stats());
};
