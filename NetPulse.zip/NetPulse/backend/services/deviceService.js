// backend/services/deviceService.js
// All direct SQL lives here. Controllers call these functions instead of
// touching the database directly.

const { db } = require('../../database/db');

const deviceService = {
  getAll() {
    return db.prepare('SELECT * FROM devices ORDER BY hostname').all();
  },

  getById(id) {
    return db.prepare('SELECT * FROM devices WHERE id = ?').get(id);
  },

  create({ hostname, ip, type = 'Device', location = '' }) {
    const result = db.prepare(`
      INSERT INTO devices (hostname, ip, type, location, status, latency_ms)
      VALUES (?, ?, ?, ?, 'online', 0)
    `).run(hostname, ip, type, location);
    return deviceService.getById(result.lastInsertRowid);
  },

  update(id, fields) {
    const existing = deviceService.getById(id);
    if (!existing) return null;
    const merged = { ...existing, ...fields };
    db.prepare(`
      UPDATE devices SET hostname=?, ip=?, type=?, location=?, status=?, latency_ms=?, last_seen=datetime('now')
      WHERE id=?
    `).run(merged.hostname, merged.ip, merged.type, merged.location, merged.status, merged.latency_ms, id);
    return deviceService.getById(id);
  },

  remove(id) {
    return db.prepare('DELETE FROM devices WHERE id = ?').run(id).changes > 0;
  },

  stats() {
    const total = db.prepare('SELECT COUNT(*) AS n FROM devices').get().n;
    const online = db.prepare("SELECT COUNT(*) AS n FROM devices WHERE status = 'online'").get().n;
    const offline = db.prepare("SELECT COUNT(*) AS n FROM devices WHERE status = 'offline'").get().n;
    const warning = db.prepare("SELECT COUNT(*) AS n FROM devices WHERE status = 'warning'").get().n;
    const avgLatencyRow = db.prepare(
      "SELECT AVG(latency_ms) AS avg FROM devices WHERE status != 'offline'"
    ).get();
    return {
      total,
      online,
      offline,
      warning,
      avgLatency: Math.round(avgLatencyRow.avg || 0),
    };
  },
};

const incidentService = {
  getAll() {
    return db.prepare(`
      SELECT incidents.*, devices.hostname, devices.ip
      FROM incidents
      JOIN devices ON devices.id = incidents.device_id
      ORDER BY incidents.detected_at DESC
      LIMIT 50
    `).all();
  },

  open(deviceId) {
    const result = db.prepare(`
      INSERT INTO incidents (device_id, status) VALUES (?, 'open')
    `).run(deviceId);
    return incidentService.getById(result.lastInsertRowid);
  },

  getById(id) {
    return db.prepare(`
      SELECT incidents.*, devices.hostname, devices.ip
      FROM incidents JOIN devices ON devices.id = incidents.device_id
      WHERE incidents.id = ?
    `).get(id);
  },

  updateStatus(id, status) {
    const resolvedAt = ['resolved', 'ignored'].includes(status) ? "datetime('now')" : 'NULL';
    db.prepare(`UPDATE incidents SET status = ?, resolved_at = ${resolvedAt} WHERE id = ?`).run(status, id);
    return incidentService.getById(id);
  },

  hasOpenIncident(deviceId) {
    return !!db.prepare(`
      SELECT 1 FROM incidents WHERE device_id = ? AND status IN ('open','investigating')
    `).get(deviceId);
  },
};

const eventService = {
  getRecent(limit = 40) {
    return db.prepare(`
      SELECT events.*, devices.hostname
      FROM events LEFT JOIN devices ON devices.id = events.device_id
      ORDER BY events.timestamp DESC, events.id DESC
      LIMIT ?
    `).all(limit);
  },

  log({ deviceId = null, severity = 'info', message }) {
    const result = db.prepare(`
      INSERT INTO events (device_id, severity, message) VALUES (?, ?, ?)
    `).run(deviceId, severity, message);
    return db.prepare(`
      SELECT events.*, devices.hostname
      FROM events LEFT JOIN devices ON devices.id = events.device_id
      WHERE events.id = ?
    `).get(result.lastInsertRowid);
  },
};

const latencyService = {
  record(avgLatency) {
    db.prepare('INSERT INTO latency_history (avg_latency) VALUES (?)').run(avgLatency);
    db.prepare(`
      DELETE FROM latency_history WHERE id NOT IN (
        SELECT id FROM latency_history ORDER BY id DESC LIMIT 60
      )
    `).run();
  },

  recent(limit = 30) {
    return db.prepare(`
      SELECT * FROM (
        SELECT * FROM latency_history ORDER BY id DESC LIMIT ?
      ) sub ORDER BY sub.id ASC
    `).all(limit);
  },
};

module.exports = { deviceService, incidentService, eventService, latencyService };
