// backend/services/monitorService.js
//
// This is the heart of NetPulse's "live" behaviour. On a fixed interval it:
//   1. Drifts latency on a random online device (simulated check)
//   2. Occasionally takes a non-critical device offline, then recovers it
//   3. Writes every change to SQLite
//   4. Opens/updates incidents when a device goes down
//   5. Emits Socket.IO events so every connected browser updates instantly
//
// Swap runCheckCycle()'s random logic for a real `ping`/`fetch` check
// (see README) and everything downstream — DB writes, incidents, sockets,
// the frontend charts — keeps working unchanged.

const { deviceService, incidentService, eventService, latencyService } = require('./deviceService');

const CHECK_INTERVAL_MS = 3500;
const OFFLINE_RECOVERY_MIN_MS = 9000;
const OFFLINE_RECOVERY_MAX_MS = 15000;
const LATENCY_WARNING_THRESHOLD = 40;

function startMonitor(io) {
  const recoveryTimers = new Map();

  function broadcastDevice(device) {
    io.emit('device:update', device);
  }

  function broadcastStats() {
    io.emit('stats:update', deviceService.stats());
  }

  function broadcastEvent(event) {
    io.emit('event:new', event);
  }

  function takeDeviceOffline(device) {
    const updated = deviceService.update(device.id, { status: 'offline' });
    broadcastDevice(updated);

    const event = eventService.log({
      deviceId: device.id,
      severity: 'critical',
      message: `${device.hostname} went offline`,
    });
    broadcastEvent(event);

    if (!incidentService.hasOpenIncident(device.id)) {
      const incident = incidentService.open(device.id);
      io.emit('incident:new', incident);
    }

    const delay = OFFLINE_RECOVERY_MIN_MS + Math.random() * (OFFLINE_RECOVERY_MAX_MS - OFFLINE_RECOVERY_MIN_MS);
    const timer = setTimeout(() => recoverDevice(device.id), delay);
    recoveryTimers.set(device.id, timer);
  }

  function recoverDevice(deviceId) {
    const device = deviceService.getById(deviceId);
    if (!device || device.status !== 'offline') return;

    const updated = deviceService.update(deviceId, {
      status: 'online',
      latency_ms: 10 + Math.round(Math.random() * 15),
    });
    broadcastDevice(updated);

    const event = eventService.log({
      deviceId,
      severity: 'info',
      message: `${device.hostname} recovered`,
    });
    broadcastEvent(event);
    broadcastStats();
    recoveryTimers.delete(deviceId);
  }

  function runCheckCycle() {
    const devices = deviceService.getAll();
    const upDevices = devices.filter((d) => d.status !== 'offline');

    // 1. Drift latency on one random online device
    if (upDevices.length) {
      const target = upDevices[Math.floor(Math.random() * upDevices.length)];
      const newLatency = Math.max(2, Math.round(target.latency_ms + (Math.random() * 10 - 5)));
      let newStatus = target.status;

      if (newLatency > LATENCY_WARNING_THRESHOLD && target.status === 'online') {
        newStatus = 'warning';
        const event = eventService.log({
          deviceId: target.id,
          severity: 'warning',
          message: `${target.hostname} latency increased to ${newLatency}ms`,
        });
        broadcastEvent(event);
      } else if (newLatency <= LATENCY_WARNING_THRESHOLD && target.status === 'warning') {
        newStatus = 'online';
      }

      const updated = deviceService.update(target.id, { latency_ms: newLatency, status: newStatus });
      broadcastDevice(updated);
    }

    // 2. Occasionally drop a non-router device offline
    const droppable = devices.filter((d) => d.status !== 'offline' && d.type !== 'Router');
    if (droppable.length && Math.random() < 0.12) {
      const target = droppable[Math.floor(Math.random() * droppable.length)];
      takeDeviceOffline(target);
    }

    // 3. Record latency history point for the chart
    const stats = deviceService.stats();
    latencyService.record(stats.avgLatency);
    broadcastStats();
    io.emit('latency:point', { timestamp: new Date().toISOString(), avgLatency: stats.avgLatency });
  }

  const interval = setInterval(runCheckCycle, CHECK_INTERVAL_MS);

  return () => {
    clearInterval(interval);
    recoveryTimers.forEach((t) => clearTimeout(t));
  };
}

module.exports = { startMonitor };
